let btn_add_tarefa = document.querySelector('#btn_add');
let input_tarefa = document.querySelector('#task_insert')
let div_painel = document.querySelector('#painel')



function insere_tarefa(tarefa) {
    let div_tarefa =  document.createElement('div')
    div_tarefa.innerHTML = `<div class="card">
                <div class="container">
                    <div class="card-body">
                        <div class="row"> 
                            <div class="col-xl-10">
                                    <div class="form-check">
                                        <h5>
                                            <input type="checkbox" class="form-check-input" id="teste">
                                                ${tarefa}
                                        </h5>
                                    </div>
                                </div>
                            <div class="col-xl-2"><button class="btn btn-dark col-12" id="btn_del">Excluir</button></div>
                        </div> 
                    </div>
                </div>
            </div>`

    div_painel.appendChild(div_tarefa)

    
}




btn_add_tarefa.addEventListener('click', function(event){
    let conteudo_tarefa = input_tarefa.value

    if (conteudo_tarefa.trim()  === ''){
        alert("Digite a sua tarefa!")
    }else{
        insere_tarefa(conteudo_tarefa)
        console.log("não sou vazio e fui clicado");
    }

    input_tarefa.value =  ''
    
})
    
let checkbox = document.querySelector("#teste")

checkbox.addEventListener('click', function(event){
        
    console.log("Aqui Estou");
    checkbox.parentNode.classList.toggle('riscado')   
    

})